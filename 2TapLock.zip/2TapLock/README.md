# ProperLockGestures
Compatible with iOS 10. 

The lock gestures in Tage doesn't work when music controls or notifications are present on the lockscreen. I thought that was annoying so I made a package for it that works. 

Double tap on lockscreen, in Notification Center or at home screen to lock the device. 
