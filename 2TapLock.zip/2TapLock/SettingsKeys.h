#define kPrefPath [NSString stringWithFormat:@"/var/mobile/Library/Preferences/se.nosskirneh.properlockgestures.plist"]
#define kSettingsChanged "se.nosskirneh.properlockgestures/preferencesChanged"

#define kHomescreen @"Homescreen"
#define kLockscreen @"Lockscreen"
#define kNotifications @"Notifications"
#define kPasscode @"Passcode"
